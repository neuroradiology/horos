The Weasis DICOM viewer requires that a Java Runtime Environment (JRE 8 or greater) be installed on your machine or be embedded in the portable distribution.

For more information about the viewer go to http://www.dcm4che.org/confluence/display/WEA/Home.